/****************************************************************
 * 'main.js'
 * Main file for javascript program
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 11-29-2017--09:30:04
 *
**/


/****************************************************************
 * Add Code Here:
**/

document.write('hello world');

/****************************************************************
 * End 'main.js'
**/

