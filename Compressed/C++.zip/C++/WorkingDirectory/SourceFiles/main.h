/****************************************************************
 * 'main.h'
 * Header file that includes the 'Utilities' code.
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 11-29-2017--11:04:36
 * THIS IS A TEST FILE CHANGES WILL NOT BE SAVED
 *
**/

#ifndef MAIN_H
#define MAIN_H

#include <iostream>
using namespace std;

#include "../../Utilities/utils.h"
#include "../../Utilities/scanner.h"
#include "../../Utilities/scanline.h"


/**
 * Add Code Here:
**/


#endif //MAIN_H

/****************************************************************
 * End 'main.h'
**/
