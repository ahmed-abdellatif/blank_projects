/*************************************************************
 * 'README.md'
 * This is a generic ReadMe file
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 11-29-2017--11:04:36
**/

/****************************************************************
 * Program:''
 * Language: Lexical Analysis Flex/Bison 
**/


/****************************************************************
 * End 'README.md'
**/


