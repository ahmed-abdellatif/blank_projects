/*************************************************************
 * 'ReadMe.txt'
 * This is a generic ReadMe file
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 09-22-2017--10:04:35
**/

/****************************************************************
 * Program:''
 * Language: JavaScript
**/


/****************************************************************
 * End 'ReadMe.txt'
**/

