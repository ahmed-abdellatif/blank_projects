/****************************************************************
 * 'Utilities.java'
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 09-22-2017--10:04:35
 *
**/

/****************************************************************
 *
**/

public class Utilities {
  public void Output(String file_name, //fuckkkkkkk ) {

  }
}//end Utilities
/****************************************************************
 * End 'Utilities.java'
**/
