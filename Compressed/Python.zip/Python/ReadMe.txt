/*************************************************************
 * 'ReadMe.txt'
 * This is a generic ReadMe file
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 10-15-2017--14:58:34
**/

/****************************************************************
 * Program:''
 * Language: Python
**/


/****************************************************************
 * End 'ReadMe.txt'
**/

