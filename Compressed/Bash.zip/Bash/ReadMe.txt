# /*************************************************************
#  * 'ReadMe.txt'
#  * This is a generic ReadMe file
#  *
#  * Author/CopyRight: Mancuso, Logan
#  * Last Edit Date: 11-29-2017--11:04:36
# **/

# /****************************************************************
#  * Program:''
#  * Language: Bash Shell Script
# **/


# /****************************************************************
#  * End 'ReadMe.txt'
# **/

