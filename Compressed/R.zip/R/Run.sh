# /****************************************************************
#  * 'Run.sh'
#  *
#  * Author/CopyRight: Mancuso, Logan
#  * Last Edit Date: 11-29-2017--11:04:36
#  *
#  * This script will run the program, run from
#  * WorkingDirectory
# **/

#!bin/bash

# /****************************************************************
#  * Error Messages
# **/

WRONG_DIRECTORY="Wrong Directory, Move To Working Directory To Run Program"
YES_OR_NO="Invalid please type [Y]es or [N]o, canceled"


if [[ ! $PWD/ = */WorkingDirectory/SourceFiles/ ]]; then
  echo $WRONG_DIRECTORY
  exit 1
fi
pwd
#  echo -n > IOFiles/xlog.txt
# running every time slows computation
echo "Executing zaRefreshDate.sh" | tee IOFiles/xlog.txt
echo "-----------------------------------------------------------------" | tee -a IOFiles/xlog.txt
../../Executable/./zaRefreshDate.sh | tee -a IOFiles/xlog.txt
echo "Executing zbBackupProgram.sh" | tee -a IOFiles/xlog.txt
echo "-----------------------------------------------------------------" | tee -a IOFiles/xlog.txt
../../Executable/./zbBackupProgram.sh | tee -a IOFiles/xlog.txt
echo "Executing zcCopyProgram.sh" | tee -a IOFiles/xlog.txt
echo "-----------------------------------------------------------------" | tee -a IOFiles/xlog.txt
../../Executable/./zcCopyProgram.sh | tee -a IOFiles/xlog.txt
#  echo -n > IOFiles/ErrorMSG.txt
read -p "Continue...? [Y]es / [N]o:    " yn_
case "$yn_" in
  [yY][eE][sS]|Y|y ) # yes
    echo "Executing zeExecute.sh" | tee IOFiles/xout.txt
    echo "-----------------------------------------------------------------" | tee -a IOFiles/xout.txt
    ../../Executable/./zeExecute.sh | tee -a IOFiles/xout.txt
    ;;
  [nN][oO]|N|n ) # no
    echo "Execution Stopped, error messages printed to ErrorMSG.txt in IO Directory"
    ;;
  * ) # else
    echo $YES_OR_NO
    ;;
esac
echo "Program Done Executing"

# /****************************************************************
#  * End 'Run.sh'
# **/
