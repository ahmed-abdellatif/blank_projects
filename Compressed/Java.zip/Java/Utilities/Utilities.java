/****************************************************************
 * 'Utilities.java'
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 11-29-2017--11:04:36
 *
**/

/****************************************************************
 *
**/

public class Utilities {
  public void Output(String file_name, //fuckkkkkkk ) {

  }
}//end Utilities
/****************************************************************
 * End 'Utilities.java'
**/
