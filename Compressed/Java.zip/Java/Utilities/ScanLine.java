/****************************************************************
 * 'ScanLine.java'
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 11-29-2017--11:04:36
 *
**/

/****************************************************************
 *
**/

public class ScanLine() {
  /****************************************************************
   * Variables
  **/
  Scanner scanner_ = new Scanner(System.in);
  
  /****************************************************************
   * Constructor 
  **/
  public ScanLine() { }
  /****************************************************************
   * Function 'HasMoreData'
  **/
  public bool HasMoreData(){
    if (ScanLine)
  }
  /****************************************************************
   * Function 'HasNext'
  **/
  public bool HasNext() {
    
  }
  /****************************************************************
   * Function 'OpenString'
  **/
  public void OpenString(String a_string_) {
    
  }
  /****************************************************************
   * Function 'Next'
  **/
  public String Next() {
    
  }
  /****************************************************************
   * Function 'NextDouble'
  **/
  public double NextInt() {
    
  }
  /****************************************************************
   * Function 'NextInt'
  **/
  public int NextInt() {
    
  }
  /****************************************************************
   * Function 'NextLong'
  **/
  public Long NextLong() {
    
  }
  /****************************************************************
   * Function 'NextLine'
  **/
  public Long NextLine() {
    
  }

}

/****************************************************************
 * End 'ScanLine.java'
**/
