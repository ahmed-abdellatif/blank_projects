/****************************************************************
 * 'Scanner.java'
 *
 * Author/CopyRight: Mancuso, Logan
 * Last Edit Date: 11-29-2017--11:04:36
 *
**/

/****************************************************************
 *
**/
import java.io.File;
import java.util.Scanner;

public class Scanner {

  /****************************************************************
  * Variables
  **/
  public String local_stream_;
  ScanLine scanline_ = new ScanLine();
  /****************************************************************
   * Constructor 
  **/
  public Scanner() { }
  /****************************************************************
   * Function 'Close'
  **/
  public void Close(){

  }
  /****************************************************************
   * Function 'HasNext'
  **/
  public bool HasNext() {

  }
  /****************************************************************
   * Function 'Next'
  **/
  public doube NextDouble() {

  }
  /****************************************************************
   * Function 'NextLine'
  **/
  public String NextLine() {
    String to_return_ = "";
    try {
      Scanner fileScanner = new Scanner(new File(fileName));
    }
    catch {

    }
  }
  /****************************************************************
   * Function 'OpenFile'
  **/
  public void OpenFile() {

  }
  /****************************************************************
   * Function 'NextInt'
  **/
  public int NextInt() {

  }
  /****************************************************************
   * Function 'NextLong'
  **/
  public Long NextLong() {

  }

}

/****************************************************************
 * End 'Scanner.java'
**/
